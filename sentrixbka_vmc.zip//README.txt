INSTRUCTIONS


1. Package content

README.txt:
This instruction file.

.png-file:
Power converter schematic. The schematic is used by the power converter model for reference and as such should be in the MATLAB(TM) path or in the same directory as the power converter model.
Note: the power converter model will work without the schematic file as well

.slx-file or .mdl file:
This file includes the power converter model used in an example application.

.p-file:
SENTRIX(TM) simulation engine.



2. Instalation

Extract the ZIP file into a free to be chosen directory/folder. Add the new directory/folder to the MATLAB(TM) path or execute the simulation directly from the chosen directory/folder.



3. Usage

The example Simulink(TM) model (.slx or .mdl-file) contains the model of the converter and is shown in an application. The converter model can be copied to other application models. Multiple instantiations of the converter model in the application are possible.

Double clicking the converter model reveals the user interface (GUI) including a schematic of the converter. The parameter values can be changed in this GUI before executing the model.

Additional information can be found by clicking the 'Help" button in the GUI.



4. Additional remarks

The speed of simulation and accuracy depend on the application model complexity and  Simulink(TM) solver settings. Try other settings when in doubt of the result.



5. IP protection
Unrightfull usage of the SENTRIX(TM) simulation engine or copying (parts of) the SENTRIX(TM) simulation engine is strictly prohibited without prior written consent of ZeoN PowerTec.



Disclaimer
ZeoN PowerTec does not accept liability for any model or simulation errors or inaccuracies and consequential loss. 

(c) ZeoN PowerTec